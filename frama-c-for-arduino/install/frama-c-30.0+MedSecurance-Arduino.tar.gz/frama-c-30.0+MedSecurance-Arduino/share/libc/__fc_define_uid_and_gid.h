/**************************************************************************/
/*                                                                        */
/*  This file is part of Frama-C.                                         */
/*                                                                        */
/*  Copyright (C) 2007-2025                                               */
/*    CEA (Commissariat à l'énergie atomique et aux énergies              */
/*         alternatives)                                                  */
/*                                                                        */
/*  you can redistribute it and/or modify it under the terms of the GNU   */
/*  Lesser General Public License as published by the Free Software       */
/*  Foundation, version 2.1.                                              */
/*                                                                        */
/*  It is distributed in the hope that it will be useful,                 */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of        */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         */
/*  GNU Lesser General Public License for more details.                   */
/*                                                                        */
/*  See the GNU Lesser General Public License version 2.1                 */
/*  for more details (enclosed in the file licenses/LGPLv2.1).            */
/*                                                                        */
/**************************************************************************/

#ifndef __FC_DEFINE_UID_AND_GID_H
#define __FC_DEFINE_UID_AND_GID_H
#include "features.h"
__PUSH_FC_STDLIB
__BEGIN_DECLS
#ifndef __gid_t_defined
typedef unsigned int gid_t;
#define __gid_t_defined 1
#endif
#ifndef __uid_t_defined
typedef unsigned int uid_t;
#define __uid_t_defined 1
#endif
__END_DECLS
__POP_FC_STDLIB
#endif

