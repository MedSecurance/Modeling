/**************************************************************************/
/*                                                                        */
/*  This file is part of Frama-C.                                         */
/*                                                                        */
/*  Copyright (C) 2007-2025                                               */
/*    CEA (Commissariat à l'énergie atomique et aux énergies              */
/*         alternatives)                                                  */
/*                                                                        */
/*  you can redistribute it and/or modify it under the terms of the GNU   */
/*  Lesser General Public License as published by the Free Software       */
/*  Foundation, version 2.1.                                              */
/*                                                                        */
/*  It is distributed in the hope that it will be useful,                 */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of        */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         */
/*  GNU Lesser General Public License for more details.                   */
/*                                                                        */
/*  See the GNU Lesser General Public License version 2.1                 */
/*  for more details (enclosed in the file licenses/LGPLv2.1).            */
/*                                                                        */
/**************************************************************************/

#ifndef __FC_NL_TYPES_H
#define __FC_NL_TYPES_H
#include "features.h"
__PUSH_FC_STDLIB
__BEGIN_DECLS

typedef unsigned long nl_catd;
typedef unsigned long nl_item;
#define NL_SETD 1
#define NL_CAT_LOCALE 1

/*@
  assigns \result \from catd;
*/
extern int catclose(nl_catd catd);

char __fc_catgets[256]; // arbitrary size
char* const __fc_p_catgets = __fc_catgets;

/*@
  assigns \result \from __fc_p_catgets, s, indirect:catd, indirect:set_id,
  indirect:msg_id;
  assigns __fc_catgets[0..] \from __fc_catgets[0..];
*/
extern char *catgets(nl_catd catd, int set_id, int msg_id, const char *s);

/*@
  assigns \result \from name[0..], oflag;
*/
extern nl_catd catopen(const char *name, int oflag);

__END_DECLS

__POP_FC_STDLIB
#endif
